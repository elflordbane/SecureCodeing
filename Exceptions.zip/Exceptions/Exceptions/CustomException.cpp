#include "CustomException.h"


myex::myex(string msg)
{
    m_msg = msg;
}

string myex::what()

{
    return m_msg;
}
