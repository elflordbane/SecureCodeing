#pragma once
#include <iostream>
#include <string.h>
using namespace std;

class myex
{
public:
    
    myex(string msg);
    string what();

private:
    string m_msg;
};






